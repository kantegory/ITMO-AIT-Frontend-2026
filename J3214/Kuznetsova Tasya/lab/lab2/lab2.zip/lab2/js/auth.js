const TravellyAuth = {
    USER_KEY: "travelly-user",
    USERS_KEY: "travelly-users",

    getUser() {
        try {
            return JSON.parse(localStorage.getItem(this.USER_KEY)) || null;
        } catch {
            return null;
        }
    },

    isLoggedIn() {
        return !!this.getUser();
    },

    getLocalUsers() {
        try {
            return JSON.parse(localStorage.getItem(this.USERS_KEY)) || [];
        } catch {
            return [];
        }
    },

    saveLocalUsers(users) {
        localStorage.setItem(this.USERS_KEY, JSON.stringify(users));
    },

    saveSession(user) {
        const session = {
            id: user.id,
            name: user.name,
            email: user.email,
            createdAt: user.createdAt
        };
        localStorage.setItem(this.USER_KEY, JSON.stringify(session));
        return session;
    },

    async login(email, password) {
        const normalizedEmail = String(email || "").trim().toLowerCase();
        const normalizedPassword = String(password || "");

        // Сначала ищем в локальном хранилище.
        const localUser = this.getLocalUsers().find(user =>
            String(user.email || "").trim().toLowerCase() === normalizedEmail &&
            String(user.password || "") === normalizedPassword
        );

        if (localUser) {
            return { success: true, user: this.saveSession(localUser) };
        }

        // Затем проверяем JSON Server, если он запущен.
        try {
            const users = await TravellyAPI.getUsers();
            const apiUser = users.find(user =>
                String(user.email || "").trim().toLowerCase() === normalizedEmail &&
                String(user.password || "") === normalizedPassword
            );

            if (apiUser) {
                const mirrored = this.getLocalUsers().filter(user =>
                    String(user.email || "").trim().toLowerCase() !== normalizedEmail
                );
                mirrored.push(apiUser);
                this.saveLocalUsers(mirrored);
                return { success: true, user: this.saveSession(apiUser) };
            }
        } catch (error) {
            console.warn("JSON Server недоступен, используется localStorage.");
        }

        return {
            success: false,
            message: "Неверный email или пароль."
        };
    },

    async register(name, email, password) {
        const cleanName = String(name || "").trim();
        const normalizedEmail = String(email || "").trim().toLowerCase();
        const cleanPassword = String(password || "");

        const localUsers = this.getLocalUsers();
        const localExists = localUsers.some(user =>
            String(user.email || "").trim().toLowerCase() === normalizedEmail
        );

        if (localExists) {
            return {
                success: false,
                message: "Пользователь с таким email уже существует."
            };
        }

        // Сначала пробуем API.
        try {
            const users = await TravellyAPI.getUsers();
            const apiExists = users.some(user =>
                String(user.email || "").trim().toLowerCase() === normalizedEmail
            );

            if (apiExists) {
                return {
                    success: false,
                    message: "Пользователь с таким email уже существует."
                };
            }

            const created = await TravellyAPI.createUser({
                name: cleanName,
                email: normalizedEmail,
                password: cleanPassword,
                createdAt: new Date().toISOString()
            });

            const mirrored = this.getLocalUsers();
            mirrored.push(created);
            this.saveLocalUsers(mirrored);

            return {
                success: true,
                user: this.saveSession(created)
            };
        } catch (error) {
            // Fallback: создаём пользователя в localStorage.
            const user = {
                id: Date.now(),
                name: cleanName,
                email: normalizedEmail,
                password: cleanPassword,
                createdAt: new Date().toISOString()
            };

            localUsers.push(user);
            this.saveLocalUsers(localUsers);

            return {
                success: true,
                user: this.saveSession(user)
            };
        }
    },

    async updateProfile(name, email) {
        const currentUser = this.getUser();
        if (!currentUser) {
            return { success: false, message: "Пользователь не авторизован." };
        }

        const normalizedEmail = String(email || "").trim().toLowerCase();

        try {
            const users = await TravellyAPI.getUsers();
            const duplicate = users.find(user =>
                String(user.email || "").trim().toLowerCase() === normalizedEmail &&
                Number(user.id) !== Number(currentUser.id)
            );

            if (duplicate) {
                return { success: false, message: "Этот email уже используется." };
            }

            const fullUser = users.find(user => Number(user.id) === Number(currentUser.id));
            if (!fullUser) throw new Error("Пользователь не найден");

            const updated = await TravellyAPI.updateUser(
                currentUser.id,
                { ...fullUser, name: String(name).trim(), email: normalizedEmail }
            );

            return { success: true, user: this.saveSession(updated) };
        } catch {
            const users = this.getLocalUsers();
            const index = users.findIndex(user => Number(user.id) === Number(currentUser.id));
            if (index === -1) {
                return { success: false, message: "Пользователь не найден." };
            }

            const duplicate = users.find((user, i) =>
                i !== index && String(user.email || "").trim().toLowerCase() === normalizedEmail
            );
            if (duplicate) {
                return { success: false, message: "Этот email уже используется." };
            }

            users[index] = {
                ...users[index],
                name: String(name).trim(),
                email: normalizedEmail
            };

            this.saveLocalUsers(users);
            return { success: true, user: this.saveSession(users[index]) };
        }
    },

    logout() {
        localStorage.removeItem(this.USER_KEY);
    },

    getKey(baseKey) {
        const user = this.getUser();
        return user ? `${baseKey}-${user.id}` : null;
    },

    updateNavigation() {
        const user = this.getUser();
        document.querySelectorAll("[data-auth-link]").forEach(link => {
            link.textContent = user ? "Профиль" : "Войти";
            link.href = user ? "profile.html" : "login.html";
        });

        const authStatus = document.getElementById("authStatus");
        if (authStatus) {
            authStatus.textContent = user ? "Профиль" : "Войти";
            authStatus.href = user ? "profile.html" : "login.html";
        }
    },

    requireAuth() {
        if (!this.isLoggedIn()) {
            const page = window.location.pathname.split("/").pop() || "index.html";
            window.location.href = `login.html?redirect=${encodeURIComponent(page)}`;
            return false;
        }
        return true;
    }
};

document.addEventListener("DOMContentLoaded", () => TravellyAuth.updateNavigation());
window.TravellyAuth = TravellyAuth;
