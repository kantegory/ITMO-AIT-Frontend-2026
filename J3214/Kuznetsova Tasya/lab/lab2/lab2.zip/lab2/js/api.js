/* =========================================================
   TRAVELLY — API
   JSON-server / REST API
   ========================================================= */

const TravellyAPI = {

    BASE_URL: "http://localhost:3000",


    async request(
        endpoint,
        options = {}
    ) {

        const response =
            await fetch(
                `${this.BASE_URL}${endpoint}`,
                {
                    headers: {
                        "Content-Type":
                            "application/json",

                        ...(options.headers || {})
                    },

                    ...options
                }
            );


        if (!response.ok) {

            throw new Error(
                `API error: ${response.status}`
            );
        }


        /*
         * Некоторые DELETE-запросы
         * не возвращают JSON.
         */

        if (response.status === 204) {
            return null;
        }


        return response.json();
    },


    /* =====================================================
       USERS
       ===================================================== */

    async getUsers() {

        return this.request(
            "/users"
        );
    },


    async getUser(id) {

        return this.request(
            `/users/${id}`
        );
    },


    async createUser(user) {

        return this.request(
            "/users",
            {
                method: "POST",
                body: JSON.stringify(user)
            }
        );
    },


    async updateUser(id, user) {

        return this.request(
            `/users/${id}`,
            {
                method: "PUT",
                body: JSON.stringify(user)
            }
        );
    },


    /* =====================================================
       DESTINATIONS
       ===================================================== */

    async getDestinations() {

        return this.request(
            "/destinations"
        );
    },


    async getDestination(id) {

        return this.request(
            `/destinations/${id}`
        );
    },


    /* =====================================================
       TRIPS
       ===================================================== */

    async getTrips() {

        return this.request(
            "/trips"
        );
    },


    async getTrip(id) {

        return this.request(
            `/trips/${id}`
        );
    },


    async createTrip(trip) {

        return this.request(
            "/trips",
            {
                method: "POST",
                body: JSON.stringify(trip)
            }
        );
    },


    async deleteTrip(id) {

        return this.request(
            `/trips/${id}`,
            {
                method: "DELETE"
            }
        );
    },


    /* =====================================================
       POSTS
       ===================================================== */

    async getPosts() {

        return this.request(
            "/posts"
        );
    },


    async getPost(id) {

        return this.request(
            `/posts/${id}`
        );
    },


    async createPost(post) {

        return this.request(
            "/posts",
            {
                method: "POST",
                body: JSON.stringify(post)
            }
        );
    },


    /* =====================================================
       SAVED DESTINATIONS
       ===================================================== */

    async getSaved(userId) {

        return this.request(
            `/saved?userId=${userId}`
        );
    },


    async saveDestination(data) {

        return this.request(
            "/saved",
            {
                method: "POST",
                body: JSON.stringify(data)
            }
        );
    },


    async deleteSaved(id) {

        return this.request(
            `/saved/${id}`,
            {
                method: "DELETE"
            }
        );
    }

};


/*
 * Делаем API доступным
 * для остальных файлов.
 */

window.TravellyAPI =
    TravellyAPI;