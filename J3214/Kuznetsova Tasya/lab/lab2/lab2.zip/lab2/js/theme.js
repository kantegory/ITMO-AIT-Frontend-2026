// ========================================
// TRAVELLY — переключение светлой/тёмной темы
// ========================================

document.addEventListener("DOMContentLoaded", () => {
    const themeToggle = document.getElementById("themeToggle");
    const themeIcon = document.getElementById("themeIcon");

    // Ключ, под которым тема будет храниться в localStorage
    const THEME_KEY = "travelly-theme";

    // Проверяем системную тему пользователя
    const systemTheme = window.matchMedia("(prefers-color-scheme: dark)");

    // Получаем сохранённую тему
    const savedTheme = localStorage.getItem(THEME_KEY);

    /**
     * Определяет текущую тему.
     * Если пользователь уже выбирал тему — используем её.
     * Если нет — смотрим настройки системы.
     */
    function getCurrentTheme() {
        if (savedTheme === "dark" || savedTheme === "light") {
            return savedTheme;
        }

        return systemTheme.matches ? "dark" : "light";
    }

    /**
     * Применяет тему к странице.
     */
    function applyTheme(theme) {
        document.documentElement.setAttribute("data-theme", theme);

        // Меняем иконку кнопки
        if (themeIcon) {
            themeIcon.textContent = theme === "dark" ? "🌙" : "☀️";
        }

        // Меняем подсказку и aria-label
        if (themeToggle) {
            if (theme === "dark") {
                themeToggle.setAttribute(
                    "aria-label",
                    "Переключить на светлую тему"
                );

                themeToggle.setAttribute(
                    "title",
                    "Переключить на светлую тему"
                );
            } else {
                themeToggle.setAttribute(
                    "aria-label",
                    "Переключить на тёмную тему"
                );

                themeToggle.setAttribute(
                    "title",
                    "Переключить на тёмную тему"
                );
            }
        }
    }

    // ========================================
    // Устанавливаем тему при загрузке
    // ========================================

    const currentTheme = getCurrentTheme();

    applyTheme(currentTheme);

    // ========================================
    // Переключение темы по кнопке
    // ========================================

    if (themeToggle) {
        themeToggle.addEventListener("click", () => {
            const current = document.documentElement.getAttribute(
                "data-theme"
            );

            const newTheme = current === "dark"
                ? "light"
                : "dark";

            // Применяем новую тему
            applyTheme(newTheme);

            // Сохраняем выбор пользователя
            localStorage.setItem(THEME_KEY, newTheme);
        });
    }

    // ========================================
    // Реакция на изменение системной темы
    // ========================================

    systemTheme.addEventListener("change", (event) => {

        // Если пользователь сам выбрал тему,
        // системные изменения её не переопределяют
        const userTheme = localStorage.getItem(THEME_KEY);

        if (userTheme) {
            return;
        }

        const newTheme = event.matches
            ? "dark"
            : "light";

        applyTheme(newTheme);
    });

    // ========================================
    // Доступ к теме из других JS-файлов
    // ========================================

    window.TravellyTheme = {
        get: () => {
            return document.documentElement.getAttribute("data-theme");
        },

        set: (theme) => {
            if (theme !== "light" && theme !== "dark") {
                return;
            }

            applyTheme(theme);
            localStorage.setItem(THEME_KEY, theme);
        },

        toggle: () => {
            const current =
                document.documentElement.getAttribute("data-theme");

            const newTheme =
                current === "dark" ? "light" : "dark";

            applyTheme(newTheme);
            localStorage.setItem(THEME_KEY, newTheme);
        }
    };
});